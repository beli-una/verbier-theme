function initListingPageAnimations() {
    $elMainSection = $(".main_section"), setTimeout("$elMainSection.addClass('animate')", 2e3);
}